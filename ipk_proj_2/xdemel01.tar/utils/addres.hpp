#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <string.h>

using namespace std;

string getTargetIP(string domainName);
string getSourceIP(string interface);